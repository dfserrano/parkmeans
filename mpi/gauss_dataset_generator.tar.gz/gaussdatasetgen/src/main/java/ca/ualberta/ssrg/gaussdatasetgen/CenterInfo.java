package ca.ualberta.ssrg.gaussdatasetgen;

import java.util.ArrayList;
import java.util.Random;

public class CenterInfo {

	private static Random random = new Random(System.currentTimeMillis());

	private DatasetVector center;
	private ArrayList<Integer> lengths;

	public CenterInfo(int dimensions) {
		center = new DatasetVector();
		lengths = new ArrayList<Integer>();
		for (int i = 0; i < dimensions; i++) {
			center.add(0d);
			lengths.add(0);
		}

		int randomNumber = random.nextInt(30);

		lengths.set(0, 10 + randomNumber);
	}

	public void setRandomInfo(int dim, double range) {
		int randomNumber = random.nextInt(30);
		lengths.set(dim, 10 + randomNumber);

		randomNumber = random.nextInt((int) Math.round(range));
		center.set(dim, new Double(randomNumber));
	}

	public int getLength(int dim) {
		return lengths.get(dim);
	}

	public void setLocationInDimension(double loc, int dim) {
		center.set(dim, loc);
	}

	public double getLocationInDimension(int dim) {
		return center.get(dim);
	}

	public DatasetVector createRandomErrorFreeVector() {
		return DatasetVector.getRandomErrorFreeVector(center, lengths);
	}

	public DatasetVector createRandomOutlierVector() {
		return DatasetVector.getRandomOutlierVector(center, lengths);
	}

	public static double getSeparation(float stdDev1, float stdDev2) {
		double f = 0.25 + (random.nextInt(50) / 100);

		return (stdDev1 + stdDev2) * f;
	}

	public DatasetVector getVector() {
		return center;
	}

	public ArrayList<Integer> getLengths() {
		return lengths;
	}

	@Override
	public String toString() {
		return center + " ::: " + lengths;
	}

}
