package ca.ualberta.ssrg.gaussdatasetgen;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class DatasetGenerator {

	private static final double PERC_OUTLIERS = 0.2;
	private static int numFeatures;
	private static int numCenters;
	private static long size;
	private static String filename;
	private static ArrayList<CenterInfo> centers = new ArrayList<CenterInfo>();

	private static Random random = new Random(System.currentTimeMillis());

	public static void main(String[] args) {

		// args
		// [0] Number of centers (k)
		// [1] Number of features of vector
		// [2] Size (Number of points)
		// [3] Output name

		if (args.length != 4) {
			System.out.println("Incorrect number of arguments");
			System.out.println("Arguments: <Centers (k)> <Dimensions (d)> <Size (n)> <Output filename>");
			System.exit(0);
		}

		numCenters = Integer.parseInt(args[0]);
		numFeatures = Integer.parseInt(args[1]);
		size = Integer.parseInt(args[2]);
		filename = args[3];
		
		try {
			File file1 = new File(filename);
			FileWriter fileWriter1 = new FileWriter(file1);
	        BufferedWriter bufferedWriter1 = new BufferedWriter(fileWriter1);

	        // if file doesnt exists, then create it
			if (!file1.exists()) {
				file1.createNewFile();
			}

			for (int i = 0; i < numCenters; i++) {
				centers.add(new CenterInfo(numFeatures));
			}

			// Find values of first dimension
			double curX = 0;
			for (int i = 0; i < numCenters; i++) {
				int curLength = centers.get(i).getLength(0);
				double firstDimension = curX + (curLength / 2);
				centers.get(i).setLocationInDimension(firstDimension, 0);

				curX += curLength
						+ CenterInfo.getSeparation(curLength / 3, centers
								.get(1).getLength(0) / 3);
			}

			double maxRange = curX;

			// Random values for other dimensions
			for (int i = 0; i < numCenters; i++) {
				for (int j = 1; j < numFeatures; j++) {
					centers.get(i).setRandomInfo(j, maxRange);
				}
			}

			for (int i = 0; i < numCenters; i++) {
				System.out.println(centers.get(i));
			}
			System.out.println();

			// Generate points
			for (long i = 0; i < size; i++) {
			
				int randomVectorIdx = random.nextInt(numCenters);
				double typeOfPoint = random.nextDouble();
				DatasetVector point;

				if (typeOfPoint > PERC_OUTLIERS) {
					// Error free
					point = centers.get(randomVectorIdx)
							.createRandomErrorFreeVector();

					// Perturbation of coordinates
					point.addErrorPerturbation(centers.get(randomVectorIdx), 1);

					// Random noise dimension
					point.addRandomNoise(maxRange);

				} else {
					// Outliers
					point = centers.get(randomVectorIdx)
							.createRandomOutlierVector();
				}

				bufferedWriter1.write(point.toString());
				bufferedWriter1.newLine();
				
				System.out.println(point);
			}
			
			bufferedWriter1.close();
			fileWriter1.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
