package ca.ualberta.ssrg.gaussdatasetgen;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class DatasetVector extends ArrayList<Double> {

	private static final long serialVersionUID = 1L;
	private static Random random = new Random(System.currentTimeMillis());
	private static int RANGE_MAX = 1000000;
	private static int RANGE_MIN = 0;

	@Override
	public String toString() {
		DecimalFormat f = new DecimalFormat("##.000");
		Iterator<Double> i = iterator();
		StringBuilder sb = new StringBuilder();

		while (i.hasNext()) {
			Double e = i.next();
			sb.append(f.format(e) + ",");
		}

		if (this.size() > 0) {
			sb.deleteCharAt(sb.length() - 1);
		}

		return sb.toString();
	}

	public static DatasetVector getRandomVector(int numFeatures) {
		DatasetVector v = new DatasetVector();

		for (int i = 0; i < numFeatures; i++) {
			v.add(getRandomDouble());
		}

		return v;
	}

	public static DatasetVector getRandomErrorFreeVector(DatasetVector center,
			ArrayList<Integer> lengths) {
		DatasetVector v = new DatasetVector();

		for (int i = 0; i < center.size(); i++) {
			RandomGaussian randomGaussian = new RandomGaussian(center.get(i),
					lengths.get(i) / 3);
			double value;
			do {
				value = randomGaussian.nextGaussian();
			} while (value < center.get(i) - (lengths.get(i) / 2)
					|| value > center.get(i) + (lengths.get(i) / 2));

			v.add(value);
		}

		return v;
	}

	public static DatasetVector getRandomOutlierVector(DatasetVector center,
			ArrayList<Integer> lengths) {
		boolean valid = false;
		DatasetVector v;

		do {
			v = new DatasetVector();

			for (int i = 0; i < center.size(); i++) {
				RandomGaussian randomGaussian = new RandomGaussian(
						center.get(i), lengths.get(i) * 3);
				double value = randomGaussian.nextGaussian();

				if (value < center.get(i) - (lengths.get(i) / 2)
						|| value > center.get(i) + (lengths.get(i) / 2)) {
					valid = true;
				}

				v.add(value);
			}
		} while (!valid);
		return v;
	}

	public void addErrorPerturbation(CenterInfo center, double factor) {
		for (int i = 0; i < center.getVector().size(); i++) {
			RandomGaussian randomGaussian = new RandomGaussian(0,
					center.getLengths().get(i) / 3);
			double error = randomGaussian.nextGaussian();
			//System.out.println("\t" + this.get(i) +" + " + (factor * error));
			this.set(i, this.get(i) + (factor * error));
		}
	}
	
	public void addRandomNoise(double max) {
		int randomDimension = random.nextInt(this.size());
		double value = max * random.nextDouble();
		
		this.set(randomDimension, value);
	}
	
	private static double getRandomDouble() {
		return RANGE_MIN + (RANGE_MAX - RANGE_MIN) * random.nextDouble();
	}
}
