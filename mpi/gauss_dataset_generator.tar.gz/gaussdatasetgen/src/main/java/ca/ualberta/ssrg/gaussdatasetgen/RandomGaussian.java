package ca.ualberta.ssrg.gaussdatasetgen;

import java.util.Random;

public final class RandomGaussian {

	private double mean;
	private double variance;
	private Random random;

	public RandomGaussian(double aMean, double aVariance) {
		random = new Random(System.currentTimeMillis());

		mean = aMean;
		variance = aVariance;
	}

	public double nextGaussian() {
		return mean + random.nextGaussian() * variance;
	}
}